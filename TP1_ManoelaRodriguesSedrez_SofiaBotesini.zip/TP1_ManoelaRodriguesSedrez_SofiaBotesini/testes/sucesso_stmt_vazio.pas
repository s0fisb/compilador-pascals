program StmtVazio;
var a : integer;
begin
  ;
  a := 1;;
  ;
end.
